def send():
    print("发送信息")