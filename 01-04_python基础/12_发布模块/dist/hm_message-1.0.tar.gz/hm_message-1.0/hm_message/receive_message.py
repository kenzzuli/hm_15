def receive():
    print("接收信息")